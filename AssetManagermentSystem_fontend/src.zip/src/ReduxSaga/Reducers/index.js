import { combineReducers } from 'redux'
import { amsReducer } from '../Reducers/amsReducer'

export default combineReducers({
    amsReducer,
})