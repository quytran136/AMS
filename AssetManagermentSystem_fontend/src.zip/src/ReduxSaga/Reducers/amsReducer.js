import { getAssetSuccess } from "../Actions/action";
import * as type from "../Type";

const initialState = {
    token: null,
    userName: null,
    tabLogin: null,
    error: null,
    cookie: null,
    userInfo: null,
    userInfoLogin: null,
    users: [],
    showMenu: true,
    organizationalChart: null,
    departmentChart: null,
    message: null,
    departmentData: null,
    organizationData: null,
    departmentDetail: null,
    signupSuccess: false,
    processFlows: null,
    warehouseAction: null,
    assetClassifies: null,
    configCommon: null,
    ticket: null,
    notifications: null
}

export const amsReducer = (state = initialState, action) => {
    switch (action?.type) {
        case type.ERROR_API:
            return {
                ...state,
                error: action.error
            }
        case type.MESSAGE:
            return {
                ...state,
                message: action.message
            }
        case type.SAVE_TOKEN:
            return {
                ...state,
                token: action.token
            }
        case type.SAVE_USER_LOGIN:
            return {
                ...state,
                userName: action.userName
            }
        case type.COOKIE:
            return {
                ...state,
                cookie: action.cookie
            }
        case type.SET_TAB_LOGIN:
            return {
                ...state,
                tabLogin: action.tab
            }
        case type.SIGNUP_SUSSESS:
            return {
                ...state,
                signupSuccess: action.result
            }
        case type.SHOW_MENU:
            return {
                ...state,
                showMenu: action.showMenu
            }
        case type.SAVE_DEPARTMENT:
            return {
                ...state,
                departmentChart: action.departmentChart
            }
        case type.DEPARTMENT_DATA:
            return {
                ...state,
                departmentData: action.department
            }
        case type.DEPARTMENT_DETAIL:
            return {
                ...state,
                departmentDetail: action.department
            }
        case type.SAVE_ORGANIZATIONAL:
            return {
                ...state,
                organizationalChart: action.organizationalChart
            }
        case type.ORGANIZATION_DATA:
            return {
                ...state,
                organizationData: action.organizational
            }
        case type.GET_USERS_SUCCESS:
            return {
                ...state,
                users: action.users
            }
        case type.GET_USER_INFO_LOGIN_SUCCESS:
            return {
                ...state,
                userInfoLogin: action.userInfo
            }
        case type.GET_USER_INFO_SUCCESS:
            return {
                ...state,
                userInfo: action.userInfo
            }
        case type.GET_USERS_BY_DEPARTMENT_SUCCESS:
            return {
                ...state,
                users: action.users
            }
        case type.SAVE_PROCESS_FLOW:
            return {
                ...state,
                processFlows: action.processFlows
            }
        case type.GET_WAREHOUSE_SUCCESS:
            return {
                ...state,
                warehouses: action.warehouses
            }
        case type.GET_ASSETCLASSIFIES_SUCCESS:
            return {
                ...state,
                assetClassifies: action.assetClassifies
            }
        case type.SET_WAREHOUSE_ACTION:
            return {
                ...state,
                warehouseAction: action.warehouseAction
            }
        case type.GET_CONFIG_COMMON:
            return {
                ...state,
                configCommon: action.configCommon
            }
        case type.GET_TICKET:
            return {
                ...state,
                ticket: action.ticket
            }
        case type.GET_NOTIFICATION_SUCCESS:
            return{
                ...state,
                notifications: action.notifications
            }
        default:
            return {
                ...state,
            }
    }

}