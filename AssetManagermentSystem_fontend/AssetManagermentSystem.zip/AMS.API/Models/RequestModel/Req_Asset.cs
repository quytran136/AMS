﻿using AMS.BUS.DBConnect;

namespace AMS.API.Models.RequestModel
{
    public class Req_Asset
    {
        public asset_classify AssetClassify { get; set; }
        public asset_detail AssetDetail { get; set; }
    }
}