﻿using AMS.BUS.DBConnect;

namespace AMS.API.Models.RequestModel
{
    public class Req_Warehouse
    {
        public store_Identifie StoreIdentifie { get; set; }
    }
}