﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AMS.API.Models.ResponseModel.Access
{
    public class Token
    {
        public string TokenString { get; set; }
    }
}