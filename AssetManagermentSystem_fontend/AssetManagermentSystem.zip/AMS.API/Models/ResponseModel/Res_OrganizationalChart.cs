﻿using AMS.BUS.BusinessHandle;

namespace AMS.API.Models.ResponseModel
{
    public class Res_OrganizationalChart
    {
        public OrganizationalChart Organizational { get; set; }
    }
}