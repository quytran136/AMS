﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMS.COMMON.Constands
{
    public class MessagesValue
    {
        public static string SUCCESS = "SUCCESS";
        public static string ERROR = "ERROR";
        public static string WARNING = "WARNING";
    }
}
