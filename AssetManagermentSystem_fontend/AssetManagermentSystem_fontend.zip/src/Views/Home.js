import React from "react";
import "./Access/Css/Common.scss";
import "./Access/Css/Home.scss";
import { Col, Row, Card } from 'antd';

function Home() {
  return (
    <div className="main-content">
      xin chào
    </div>
  );
}

export default Home;
