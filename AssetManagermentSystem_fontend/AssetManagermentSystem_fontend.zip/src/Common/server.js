// export const SERVER_API = "http://api.qntech.xyz/api/"
export const SERVER_API = "http://localhost/AMS/api/"