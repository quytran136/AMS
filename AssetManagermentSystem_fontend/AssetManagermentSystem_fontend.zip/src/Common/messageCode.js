export const WARNING = "WARNING";
export const ERROR = "ERROR";
export const SUCCESS = "SUCCESS";

export const ERROR_CODE = {
    WrongUserNameOrPassword: "Sai tài khoản hoặc mật khẩu",
    UserOrPasswordIsEmpty: "Tài khoản hoặc mật khẩu trống",
}